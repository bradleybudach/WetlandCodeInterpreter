﻿import arcpy

try:
    print("Hello - this message is from a TEST Python script")
    
except Exception as ex:
    
    print("Exception occurred!")